---
Topic:
    - 新闻资讯

Field:
    - 机器学习/分类
,    - 自然语言处理

License:
    - CC0 公共领域共享

Ext:
    - .txt

DatasetUsage:
    - 169405737
---



## **数据说明**
本次训练使用了其中的10个分类（体育, 财经, 房产, 家居, 教育, 科技, 时尚, 时政, 游戏, 娱乐），每个分类6500条，总共65000条新闻数据。

数据集划分如下：

cnews.train.txt: 训练集(50000条)

cnews.val.txt: 验证集(5000条)

cnews.test.txt: 测试集(10000条)


## **问题描述**
nlp的文本分类问题。

## **引用格式**
```
@misc{new3021,
    title = { THUCNews新闻文本分类数据集 },
    author = { Ustinian },
    howpublished = { \url{https://www.heywhale.com/mw/dataset/5de4b6d0ca27f8002c4c530a} },
    year = { 2019 },
}
```